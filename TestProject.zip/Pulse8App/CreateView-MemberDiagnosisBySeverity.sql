USE Pulse8TestDB;
GO
-- Assumptions:  That the instruction 'please set this to 1 for Members without corresponding Categories 
--               as well' means: If there is only 1 MemberDiagnosis record for a member and if that 
--               diagnosis has no category associated with it, then that diagnosis is by default the most severe.

CREATE VIEW dbo.MemberDiagnosisBySeverity AS
SELECT 
	m.MemberID AS 'Member ID',
	m.FirstName AS 'First Name',
	m.LastName AS 'Last Name',
	msdc.MostSevereDiagnosisID AS 'Most Severe Diagnosis ID',
	d.DiagnosisDescription AS 'Most Severe Diagnosis Description',
	ISNULL(msdc.DiagnosisCategoryID, 0) AS 'Category ID',
	dc.CategoryDescription AS 'Category Description',
	dc.CategoryScore AS 'Category Score',
	msdc.IsMostSevereCategory AS 'Is Most Severe Category'
  FROM dbo.Member m
	  LEFT JOIN dbo.MemberDiagnosis md
		   ON m.MemberID = md.MemberID 
	  LEFT JOIN dbo.Diagnosis d
		   ON d.DiagnosisID = md.DiagnosisID
	  LEFT JOIN dbo.DiagnosisCategoryMap dcm
		   ON dcm.DiagnosisID = md.DiagnosisID
	  LEFT JOIN dbo.DiagnosisCategory dc
		   ON dc.DiagnosisCategoryID = dcm.DiagnosisCategoryID
	  LEFT JOIN (SELECT 
					  md2.MemberID AS MemberID,
					  MIN(md2.DiagnosisID) AS MostSevereDiagnosisID,
					  ISNULL(dcm2.DiagnosisCategoryID, 0) AS DiagnosisCategoryID,
					  CASE WHEN (xmsdc.MinCat = dcm2.DiagnosisCategoryID OR xmsdc.MinCat = 999) THEN 1 
					  	   ELSE 0 
					  END AS IsMostSevereCategory
				  FROM dbo.MemberDiagnosis md2
					  LEFT JOIN dbo.DiagnosisCategoryMap dcm2
						   ON dcm2.DiagnosisID = md2.DiagnosisID
					  CROSS APPLY (SELECT
  									   MIN(ISNULL(xdcm.DiagnosisCategoryID, 999)) AS MinCat
									 FROM dbo.MemberDiagnosis xmd
										 LEFT JOIN dbo.DiagnosisCategoryMap xdcm
											  ON xdcm.DiagnosisID = xmd.DiagnosisID
									WHERE xmd.MemberID = md2.MemberId
					  ) AS xmsdc
				  GROUP BY md2.MemberID, 
						   dcm2.DiagnosisCategoryID, 
						   xmsdc.MinCat
      ) AS msdc
	  ON msdc.MemberID = m.MemberID 
  WHERE msdc.MostSevereDiagnosisID = md.DiagnosisID 
     OR msdc.MostSevereDiagnosisID is null

  GO