﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P8DataAccess;

namespace P8DataAccess.Repository
{
    public class MemberDiagnosisBySeverityRepository
    {
        public List<MemberDiagnosisBySeverity> GetMemberDiag(int memberId)
        {
            using (var db = new Pulse8TestDBEntities())
            {
                return (from m in db.MemberDiagnosisBySeverities
                        where m.Member_ID == memberId
                        orderby m.Category_ID, m.Most_Severe_Diagnosis_ID
                        select m).ToList();
            }
        }
    }
}
