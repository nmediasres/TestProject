USE Pulse8TestDB;

SELECT 
	  m.MemberID AS 'Member ID',
	  m.FirstName AS 'First Name',
	  m.LastName AS 'Last Name',
	  msdc.MostSevereDiagnosisID AS 'Most Severe Diagnosis ID',
	  d.DiagnosisDescription AS 'Most Severe Diagnosis Description',
	  ISNULL(msdc.DiagnosisCategoryID, 0) AS 'Category ID',
	  dc.CategoryDescription AS 'Category Description',
	  dc.CategoryScore AS 'Category Score',
	  ISNULL(msdc.IsMostSevereCategory, 1) AS 'Is Most Severe Category'
  FROM dbo.Member m
	  LEFT JOIN dbo.MemberDiagnosis md
		   ON m.MemberID = md.MemberID 
	  LEFT JOIN dbo.Diagnosis d
		   ON d.DiagnosisID = md.DiagnosisID
	  LEFT JOIN dbo.DiagnosisCategoryMap dcm
		   ON dcm.DiagnosisID = md.DiagnosisID	
	  LEFT JOIN dbo.DiagnosisCategory dc
		   ON dc.DiagnosisCategoryID = dcm.DiagnosisCategoryID
	  LEFT JOIN (SELECT 
					   md2.MemberID,
					   MIN(md2.DiagnosisID)  AS MostSevereDiagnosisID,
					   ISNULL(dcm2.DiagnosisCategoryID, 0) AS DiagnosisCategoryID,
					   CASE WHEN (MIN(dcm2.DiagnosisCategoryID) 
					             OVER(PARTITION BY md2.MemberID ORDER BY dcm2.DiagnosisCategoryID)= dcm2.DiagnosisCategoryID) THEN 1
					        WHEN (MIN(ISNULL(dcm2.DiagnosisCategoryID, 999)) OVER(PARTITION BY md2.MemberID) = 999) THEN 1 
					   	 ELSE 0 
					   END AS IsMostSevereCategory  
				   FROM dbo.MemberDiagnosis md2
					   LEFT JOIN dbo.DiagnosisCategoryMap dcm2	
						    ON md2.DiagnosisID = dcm2.DiagnosisID
				  GROUP BY md2.MemberID, 
					       dcm2.DiagnosisCategoryID
				) msdc
	       ON msdc.MemberID = m.MemberID 
  WHERE msdc.MostSevereDiagnosisID = md.DiagnosisID 
     OR msdc.MostSevereDiagnosisID is null
  ORDER BY m.memberID, 
           dc.DiagnosisCategoryID

  GO
