﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P8DataAccess;

namespace Pulse8App
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Please enter a Member Id : (\"quit\" to exit.)");
                var memberid = Console.ReadLine();
                int memId = 0;
                if (int.TryParse(memberid, out memId))
                {
                    var P8Repo = new P8DataAccess.Repository.MemberDiagnosisBySeverityRepository();
                    var recs = P8Repo.GetMemberDiag(memId);
                    if (recs != null && recs.Count > 0)
                    {
                        foreach (var m in recs)
                        {
                            Console.WriteLine(string.Format("Member : {0} - Name : {1}, {2}", m.Member_ID, m.Last_Name, m.First_Name));
                            Console.WriteLine(string.Format("Most Severe Diagnosis : {0} - {1}", m.Most_Severe_Diagnosis_ID, m.Most_Severe_Diagnosis_Description));
                            Console.WriteLine(string.Format("Diagnosis Category    : {0} - {1} - {2} {3}", m.Category_ID, m.Category_Description, m.Category_Score, (m.Is_Most_Severe_Category == 1 ? " ** Most Severe Category **" : "")));
                            Console.WriteLine();
                        }
                    }
                    else
                    {
                        Console.WriteLine(string.Format("No diagnosis records for member: {0}", memberid));
                        Console.WriteLine();
                    }
                }
                else if (memberid.Equals("quit", StringComparison.InvariantCultureIgnoreCase))
                {
                    break;
                }
                else
                {
                    Console.WriteLine(string.Format("Member ID {0} not found.", memberid));
                    Console.WriteLine();
                }
            }

        }
    }
}
