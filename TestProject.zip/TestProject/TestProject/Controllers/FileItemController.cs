﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using FileServer.Controllers;

namespace TestProject.Controllers
{
    /// <summary>
    /// Class FileItemController.
    /// </summary>
    /// <seealso cref="System.Web.Mvc.Controller" />
    public class FileItemController : Controller
    {

        /// <summary>
        /// Searches for files and directories/subdirectories matching the criteria.
        /// </summary>
        /// <param name="path">Starting point of the search.</param>
        /// <param name="criteria">The search criteria.</param>
        /// <param name="pattern">The pattern.</param>
        /// <returns>JsonResult - object containing an array of Directories and an array of Files.</returns>
        public JsonResult SearchFiles(string path, string criteria, string pattern)
        {
            var repo = new FileServerController();
            try
            {
                return repo.SearchFiles(path, criteria, pattern); 
            }
            catch (Exception ex)
            {
                return Json(new { Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Return the current directory's top level directories and files..
        /// </summary>
        /// <param name="path">The directory path to query.</param>
        /// <returns>JsonResult - object containing an array of Directories and an array of Files.</returns>
        public JsonResult FileList(string path)
        {
            var repo = new FileServerController();
            try
            {
                return repo.FileList(path);
            }
            catch (Exception ex)
            {
                return Json(new { Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Download the specified file.
        /// </summary>
        /// <param name="path">The file path.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>FileResult - download file.</returns>
        public FileResult GetFile(string path, string fileName)
        {
            var repo = new FileServerController();
            return repo.GetFile(path, fileName);
        }

        /// <summary>
        /// Uploads the file to the specified directory.
        /// Method is asynchronous.  Returns a Json Object containing status 
        /// when complete or on error.
        /// </summary>
        /// <param name="dirpath">The directory to store the file in.</param>
        /// <returns>Asynchronous jsonResult</returns>
        public async Task<JsonResult> UploadFile(string dirpath)
        {
            var repo = new FileServerController();
            return await repo.UploadFile(Request, dirpath);
        }
    }
}
