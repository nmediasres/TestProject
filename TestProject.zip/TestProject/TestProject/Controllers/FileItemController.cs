﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;

using TestProject.Repositories;

namespace TestProject.Controllers
{
    /// <summary>
    /// Class FileItemController.
    /// </summary>
    /// <seealso cref="System.Web.Mvc.Controller" />
    public class FileItemController : Controller
    {

        /// <summary>
        /// Searches for files and directories/subdirectories matching the criteria.
        /// </summary>
        /// <param name="path">Starting point of the search.</param>
        /// <param name="criteria">The search criteria.</param>
        /// <param name="pattern">The pattern.</param>
        /// <returns>JsonResult - object containing an array of Directories and an array of Files.</returns>
        public JsonResult SearchFiles(string path, string criteria, string pattern)
        {
            var repo = new FileItemRepository();
            try
            {
                object o = repo.SearchDirectory(path, criteria, pattern);
                return Json(new { Objects = o }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Return the current directory's top level directories and files..
        /// </summary>
        /// <param name="path">The directory path to query.</param>
        /// <returns>JsonResult - object containing an array of Directories and an array of Files.</returns>
        public JsonResult FileList(string path)
        {
            var repo = new FileItemRepository();
            try
            {
                object o = repo.GetDirectoryObjects(path);
                return Json(new { Objects = o }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Download the specified file.
        /// </summary>
        /// <param name="path">The file path.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>FileResult - download file.</returns>
        public FileResult GetFile(string path, string fileName)
        {
            var repo = new FileItemRepository();
            byte[] fileBytes = repo.GetFileBytes(path, fileName);
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }

        /// <summary>
        /// Uploads the file to the specified directory.
        /// Method is asynchronous.  Returns a Json Object containing status 
        /// when complete or on error.
        /// </summary>
        /// <param name="dirpath">The directory to store the file in.</param>
        /// <returns>Asynchronous jsonResult</returns>
        public async Task<JsonResult> UploadFile(string dirpath)
        {
            try
            {
                var repo = new FileItemRepository();
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        // get input stream
                        var stream = fileContent.InputStream;
                        await repo.UploadFile(dirpath, stream, fileContent.FileName);
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new { Status = "Failed", Reason = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { Status = "Ok" }, JsonRequestBehavior.AllowGet);
        }
    }
}
