﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace TestProject.Models
{
    public class DirectoryItem
    {
        public DirectoryItem(DirectoryInfo info)
        {
            Name = info.Name;
            Path = info.FullName;
            Modified = info.LastWriteTime;
            Info = info;
            Parent = info.Parent.FullName;
        }
        public string Name { get; set; }
        public string Path { get; set; }
        public string Parent { get; set; }
        public DateTime Modified { get; set; }
        public long FileCount { get; set; }
        public bool HasPermission { get; set; }

        internal DirectoryInfo Info { get; set;  }

    }
}