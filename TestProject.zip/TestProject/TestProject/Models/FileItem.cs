﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace TestProject.Models
{
    public class FileItem
    {
        public FileItem (FileInfo info)
        {
            Name = info.Name;
            Path = info.DirectoryName;
            Created = info.CreationTime;
            Modified = info.LastWriteTime;
            Size = info.Length;
        }
        public string Name { get; set; }
        public string Path { get; set; }
        public DateTime Created { get; set; }
        public DateTime Modified { get; set; }
        public long Size { get; set; }

    }
}