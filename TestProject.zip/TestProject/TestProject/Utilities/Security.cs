﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Web;

namespace TestProject.Utilities
{
    public class Security
    {
        /// <summary>
        /// Shamelessly copied from  https://stackoverflow.com/questions/11709862/check-if-directory-is-accessible-in-c
        /// Determines whether the user can read the directory at the specified path.
        /// This method catches most of the unreadable directories but it does produce some false negatives.
        /// It is used because it catches unreadable directories without throwing an exception.
        /// </summary>
        /// <param name="path">Full directory name</param>
        /// <returns><c>true</c> if this instance can read the specified path; otherwise, <c>false</c>.</returns>
        internal static bool CanRead(string path)
        {
            var readAllow = false;
            var readDeny = false;
            var accessControlList = Directory.GetAccessControl(path);
            if (accessControlList == null)
                return false;
            var accessRules = accessControlList.GetAccessRules(true, true, typeof(System.Security.Principal.SecurityIdentifier));
            if (accessRules == null)
                return false;

            foreach (FileSystemAccessRule rule in accessRules)
            {
                if ((FileSystemRights.Read & rule.FileSystemRights) != FileSystemRights.Read) continue;

                if (rule.AccessControlType == AccessControlType.Allow)
                    readAllow = true;
                else if (rule.AccessControlType == AccessControlType.Deny)
                    readDeny = true;
            }

            return readAllow && !readDeny;
        }
    }
}