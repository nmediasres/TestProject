﻿"use strict";
var testProject = {
    defaultDirectory: "C:\\",
    //--------------------------------------------------------------------------------------------
    // Presenters
    //--------------------------------------------------------------------------------------------

    //--------------------------------------------------------------------------------------------
    // view    : The html view the presenter manipulates
    // returns : Object with public methods:
    //             getFileList(path)
    //             getFileListByDir(path)
    //             getView()
    //             ready(self)
    //--------------------------------------------------------------------------------------------
    ListPresenter: function (view) {
        var _localFilePath = "";
        var _localFilter = "";
        var _model;
        var _selectedFiles;
        var _self;
        var _view;

        var clearDisplay = function () {
            $("#filelist").empty();
            $("#parentDirectory").html("");
            setResultLabel();
        };
        //--------------------------------------------------------------------------------------------
        // self  : the global var holding the reference to this instance of the ListPresenter
        //
        // Called from the $(document).ready() method fired when the main form is finished loading.
        // Saves the reference to self
        // Wires up the controls, sets the url and displays the files in the indicated directory.
        //--------------------------------------------------------------------------------------------
        var documentReady = function (self) {
            _self = self;
            getUrlHash();
            wireupHashChange();
            wireupUiControls();
            // Display the files in the default directory
            $("input#dirpath").val(_localFilePath);
            getFiles($("input#dirpath").val());
        };
        //--------------------------------------------------------------------------------------------
        // Saves a reference to the view, gets the default directory if needed, then renders the page.
        //--------------------------------------------------------------------------------------------
        var init = function () {
            _view = view;
            if (_localFilePath === "") {
                _localFilePath = testProject.defaultDirectory;
            }
            // render the view on the page
            $("body").append(_view.getHtml());
        };
        //--------------------------------------------------------------------------------------------
        // path   :  Directory to search.
        //
        // Ajax method to call FileList or SearchFiles
        // Enforces three character minimum for search criteria.
        // Clears the display before making ajax call.
        // On success - updates the url hash and calls methods to display the results.
        // On fail - clears the results label and displays an alert popup.
        //--------------------------------------------------------------------------------------------
        var getFiles = function (path) {
            var _isSearch = $("input#chkSearchSubDirectories").prop("checked") === true;
            var _uri = "FileItem/" + (_isSearch ? "SearchFiles" : "FileList");
            if (!path) {
                path = _localFilePath;
            }
            else {
                _localFilePath = path;
            }
            $("input#dirpath").val(_localFilePath);
            var _data = {
                path: path
            };
            if (_isSearch) {
                var _filter = $("input#filter").val();
                _filter = util.removeWildCards(_filter);
                if (_filter.length < 3) {
                    alert("Minimum filter length is three characters");
                    return;
                }
                else {
                    $.extend(_data, {
                        criteria: _filter,
                        pattern: "*.*"
                    });
                }
            }
            clearDisplay();
            $.ajax({
                url: _uri,
                type: "get",
                cache: false,
                data: _data
            })
            .done(function (data) {
                setUrlHash(_localFilePath);
                if (data.Objects) {
                    setResultData(data.Objects);
                    setParentDirectoryLink();
                }
                else if (data.Error) {
                    setResultLabel(data);
                    alert(data.Error);
                }
            })
            .fail(function (jqXhr, textStatus, errorThrown) {
                setResultLabel({ Error: errorThrown });
                alert("Error: GetFiles call " + _uri + " failed to return data.  The error is: " + errorThrown);
            })
            .always(function () {
            });
        };
        //--------------------------------------------------------------------------------------------
        // path  : directory to search
        //
        // This call is from the click event of a directory link.
        // Resets the subdirectory search button, clears the checkbox and the criteria. 
        // Then calls getFiles().
        //--------------------------------------------------------------------------------------------
        var getFilesByDir = function (path) {
            $("input#chkSearchSubDirectories").prop("checked", false);
            $("input#filter").val("");
            $("input#showfiles").val("Show Files");
            getFiles(path);
        };
        //--------------------------------------------------------------------------------------------
        // Called by ready()
        // In the event that there is a hash in the url when the application is initially loaded,
        // this method extracts the path and filter, if any, and sets up the page controls so the 
        // application will open in the state indicated by the hash.
        //--------------------------------------------------------------------------------------------
        var getUrlHash = function () {
            var _pageName = window.document.location.toString().substring(window.document.location.origin.length);
            if (_pageName.indexOf("#!") > 0) {
                var _hash = _pageName.split("#!")[1];
                var _cleanHash = util.getCleanHash(_hash);
                if (Object.prototype.toString.apply(_cleanHash) === "[object Array]") {
                    _localFilePath = _cleanHash[0];
                    if (typeof _cleanHash[1] === "string" && _cleanHash[1].length) {
                        _localFilter = _cleanHash[1];
                        $("input#chkSearchSubDirectories").prop("checked", true);
                        $("input#filter").val(_localFilter);
                    }
                    $("input#showfiles").val($(this).prop("checked") ? "Search" : "Show files");
                }
            }
        };
        //--------------------------------------------------------------------------------------------
        // Zeros out the file upload progress bar and refreshes the 
        // directory listing to reflect the newly uploaded file.
        //--------------------------------------------------------------------------------------------
        var handleUploadDone = function () {
            $("progress").attr("value", "0");
            $("#fileinput").val("");
            _self.getFileList($("input#dirpath").val());
        };
        //--------------------------------------------------------------------------------------------
        // A custom xhr method to drive the progress control.
        // For handling the progress of the upload
        //--------------------------------------------------------------------------------------------
        var progressListener = function () {
            var _pl = $.ajaxSettings.xhr();
            if (_pl.upload) {
                _pl.upload.addEventListener("progress", function (e) {
                    if (e.lengthComputable) {
                        $("progress").attr({
                            value: e.loaded,
                            max: e.total
                        });
                    }
                }, false);
            }
            return _pl;
        };
        //--------------------------------------------------------------------------------------------
        // Populates the link in the directory listing that displays the parent directory.
        //--------------------------------------------------------------------------------------------
        var setParentDirectoryLink = function () {
            var _dir = _localFilePath;
            var _url = window.document.location;
            if (util.isRootDirectory(_dir)) {
                $("#parentDirectory").html("");
                $("#currentDirectory").html("");
            }
            else {
                // trim off the last \ if applicable
                if (_dir.lastIndexOf("\\") === _dir.length) {
                    _dir = _dir.substr(0, _dir.lastIndexOf("\\"));
                }
                // Get the complete path of the parent directory
                var _parentDir = _dir.substr(0, _dir.lastIndexOf("\\"));
                var _currentDir = _dir.substr(_dir.lastIndexOf("\\"));
                if (_parentDir.length === 2) {
                    _parentDir += "\\"; // add \ to root directory
                }
                // populate the html object with parent and current directory
                $("#parentDirectory").html("&lt;dir&gt;" + _parentDir);
                var _href = _url.origin + _url.pathname + _url.search + "#!" + _parentDir;
                $("#parentDirectory").attr("href", _href);
                $("#parentDirectory").unbind("click");
                var _parentSelf = _self; // required for closure.
                $("#parentDirectory").click(function (e) {
                    e.preventDefault();
                    _parentSelf.getFileListByDir(_parentDir);
                });
                $("#currentDirectory").html(_currentDir);
            }
        };
        //--------------------------------------------------------------------------------------------
        // obj  : Object containing Array of Files and or Directories
        // 
        // Instantiates new presenters for files and directories and appends the
        // html produced to the filelist control.  Then updates the results metrics.
        //--------------------------------------------------------------------------------------------
        var setResultData = function (obj) {
            var _presenter;
            var _parentSelf = _self;  // required for closure
            if (obj.Directories) {
                _presenter = new testProject.FileItemPresenter(new testProject.DirectoryView(), _parentSelf);
                $.each(obj.Directories, function (key, item) {
                    $(_presenter.populateListItem(new testProject.DirectoryModel(item))).appendTo($("#filelist"));
                });
            }
            if (obj.Files) {
                _presenter = new testProject.FileItemPresenter(new testProject.FileView());
                $.each(obj.Files, function (key, item) {
                    $(_presenter.populateListItem(new testProject.FileModel(item))).appendTo($("#filelist"));
                });
            }
            setResultLabel(obj);
        };
        //--------------------------------------------------------------------------------------------
        // obj  : Object containing Array of Files and or Directories
        // 
        // Populates the result metrics display with File and Directory counts and
        // shows or hides the search progress bar as appropriate.
        //--------------------------------------------------------------------------------------------
        var setResultLabel = function (obj) {
            if (obj && typeof obj === "object") {
                if (typeof obj.Error !== "undefined") {
                    $("#resultCounts").html("No results.");
                    $("#searchProgress").hide();
                    $("#parentDirectory").html("");
                }
                else {
                    var _dircount = (obj.Directories.length === 1) ? "1 directory" : obj.Directories.length + " directories";
                    var _filecount = (obj.Files.length === 1) ? "1 file" : obj.Files.length + " files";
                    $("#resultCounts").html("Returned : {DIRCOUNT}, {FILECOUNT}".replace("{DIRCOUNT}", _dircount).replace("{FILECOUNT}", _filecount));
                    $("#searchProgress").hide();
                }
            }
            else {
                $("#resultCounts").html("Searching");
                $("#searchProgress").show();
                $("#parentDirectory").html("");
            }
        };
        //--------------------------------------------------------------------------------------------
        // path   : directory to save in hash string.
        // filter : search criteria to save in hash string.
        //
        // Builds a string containing the current path and filter, if any, to be used in the url hash.
        //--------------------------------------------------------------------------------------------
        var setUrlHash = function (path, filter) {
            debugger;
            var _pageName = window.document.location.toString().substring(window.document.location.origin.length);
            var _currentHash;
            // prevent the double hash
            if (_pageName.substr(_pageName.length - 1) === "#") {
                _pageName = _pageName.substr(0, _pageName.length - 1);
            }
            if (_pageName.indexOf("#!") > 0) {
                var _page = _pageName.split("#!");
                _pageName = _page[0];
                _currentHash = _page[1];
            }
            var _cleanArg = util.getCleanArg(path, $("input#filter").val());
            if (_cleanArg !== _currentHash) {
                window.history.pushState(_pageName + "#!" + _currentHash, "", _pageName + "#!" + _cleanArg);
            }
        };
        //--------------------------------------------------------------------------------------------
        // Ajax method to upload a file to the server.
        // Uses a custom xhr to drive a progress bar.
        // Calls handleUploadDone() on success.
        //--------------------------------------------------------------------------------------------
        var uploadFiles = function () {
            var _uri = "FileItem/UploadFile?dirpath=" + _localFilePath;
            var _files = _selectedFiles;
            if (_files.length > 0) {
                var _data = new FormData();
                for (var x = 0; x < _files.length; x++) {
                    _data.append("file" + x, _files[x]);
                }
                $.ajax({
                    url: _uri,
                    type: "POST",
                    data: _data,
                    cache: false,
                    contentType: false,
                    processData: false,
                    xhr: progressListener
                })
                .done(function (data) {
                    if (data.Status === "Ok") {
                        handleUploadDone();
                    }
                })
                .fail(function (jqXhr, textStatus, errorThrown) {
                    alert("Error: FileUpload call " + _uri + " failed.  The error is: " + errorThrown);
                })
                .always(function () {
                });
            }
        };
        //--------------------------------------------------------------------------------------------
        // Adds an event to window.onhashchange.
        // N.B.  Overrides default behavior of the window.onhashchange event.
        //--------------------------------------------------------------------------------------------
        var wireupHashChange = function () {
            window.onhashchange = function (e) {
                e.preventDefault();
                var _hash = window.document.location.hash.substr(2);
                var _cleanHash = "";
                var _url = "";
                var _filter;
                if (_hash.length) {
                    _cleanHash = util.getCleanHash(_hash);
                    if (Object.prototype.toString.apply(_cleanHash) === "[object Array]") {
                        _url = _cleanHash[0];
                        // If there is a hash in the url
                        //    Clean it up so it can be used by showFiles().
                        // If the hash contains a filter
                        //    Set the page controls up for a directory search.
                        // Otherwise
                        //    Set the page up for a top level listing.
                        // If there is a change to either the path or the filter
                        //    Call getFiles().
                        if (typeof _cleanHash[1] === "string" && _cleanHash[1].length) {
                            _filter = _cleanHash[1];
                            $("input#chkSearchSubDirectories").prop("checked", true);
                            $("input#filter").val(_filter);
                        }
                        else {
                            $("input#chkSearchSubDirectories").prop("checked", false);
                            $("input#filter").val("");
                        }
                        $("input#showfiles").val($("input#chkSearchSubDirectories").prop("checked") ? "Search" : "Show files");
                    }
                    if (_localFilePath !== _url || _localFilter !== _filter) {
                        getFiles(_url);
                    }
                }
            };
        };
        //--------------------------------------------------------------------------------------------
        // wire ups for the following controls:
        //      directory input.keypress event
        //      button click events for show/search button and file upload button
        //      checked-change event for the search check box
        //      change event for the file input browser
        //--------------------------------------------------------------------------------------------
        var wireupUiControls = function () {
            $("input#dirpath").on("keypress", function (e) {
                if (e.keyCode == 13) {
                    getFiles($("input#dirpath").val());
                }
            });
            $("input#showfiles").click(function () {
                getFiles($("input#dirpath").val());
            });
            $("input#chkSearchSubDirectories").change(function () {
                if ($(this).prop("checked")) {
                    $("input#showfiles").val("Search");
                }
                else {
                    $("input#showfiles").val("Show files");
                    $("input#filter").val("");
                }
            });
            $("#fileinput").on("change", function (e) {
                _selectedFiles = e.target.files;
                $("progress").attr("value", "0");
            });
            $("#getfile").click(function (e) {
                uploadFiles();
            });
        };
        init();

        return {
            getFileList: function (path) {
                getFiles(path);
            },
            getFileListByDir: function (path) {
                getFilesByDir(path);
            },
            getView: function () {
                return _view;
            },
            ready: function (self) {
                documentReady(self);
            },
        };
    },
    //--------------------------------------------------------------------------------------------
    // view   : the view to populate.  accepts either a FileView or DirectoryView
    // that   : reference to the current instance of ListPresenter - used for closure in the click event.
    //
    // returns: Object with public methods:
    //            getView()
    //            populateListItem(model)
    //--------------------------------------------------------------------------------------------
    FileItemPresenter: function (view, that) {
        var _that;
        var _view;
        var init = function() {
            _that = that; // required for closure.
            _view = view;
        }
        //--------------------------------------------------------------------------------------------
        // html  : html object
        // model : Model for html object
        //
        // Click handler is added if _that is an object.
        // Currently intended for DirectoryView only.
        //--------------------------------------------------------------------------------------------
        var addClickHandler = function (html, model) {
            var _details = model.getDetails();
            html.find("a").click(function (e) {
                e.preventDefault();
                _that.getFileListByDir(_details.path);
            });
        };
        init();

        return {
            getView: function () {
                return _view;
            },
            populateListItem: function (model) {
                // Call the populateListItem method in the view itself.
                var _html = _view.populateListItem(model);
                // Add a click handler if _that is valid.
                if (_that && typeof _that === "object") {
                    addClickHandler(_html, model);
                }
                return _html;
            },
        };
    },
    //--------------------------------------------------------------------------------------------
    // Views
    //--------------------------------------------------------------------------------------------

    //--------------------------------------------------------------------------------------------
    // Returns : Object with one public method : 
    //             getHtml() 
    //--------------------------------------------------------------------------------------------
    ListView: function () {
        var _html;

        function init() {
            // html for the main view of the application.
            _html = $('<div>' +
                        '<fieldset><legend>Set server file directory</legend>' +
                            '<label>Directory</label>' +
                            '<input type="text" id="dirpath" size="50" />' +
                            '<label>Filter</label><input type="text" id="filter" size="20" />' +
                            '<input id="chkSearchSubDirectories" type="checkbox" class="check-box"/><label>Search subdirectories</label>' +
                            '<input id="showfiles" type="button" value="Show files" />' +
                            '<label id="resultCounts"></label>' +
                            '<progress id="searchProgress" hidden></progress>' +
                        '</fieldset>' +
                    '</div>' +
                    '<div>' +
                        '<fieldset><legend>File list</legend>' +
                            '<a id="parentDirectory" href="#">parent&lt;&lt;</a>' +
                            '<span id="currentDirectory"></span>' +
                            '<ul id="filelist"></ul>' +
                        '</fieldset>' +
                    '</div>' +
                    '<div>' +
                        '<fieldset><legend>Upload local file to server</legend>' +
                            '<input id="fileinput" type="file"/>' +
                            '<input id="getfile" type="submit" class="uploadbutton" value="Upload" /><progress value="0"></progress>' +
                        '</fieldset>' +
                    '</div>');
        };
        init();

        return {
            getHtml: function () {
                return _html;
            }
        };
    },
    //--------------------------------------------------------------------------------------------
    // Returns : Object with one public method : 
    //             populateListItem()
    //--------------------------------------------------------------------------------------------
    DirectoryView: function () {
        var _html;
        //--------------------------------------------------------------------------------------------
        // model   : DirectoryModel
        // returns : Html populated with model data.
        //
        // Builds populated html object for a Directory item (model).
        //--------------------------------------------------------------------------------------------
        function populate(model) {
            init();
            var _details = model.getDetails()
            var _url = window.document.location;
            var _href = _url.origin + _url.pathname + _url.search + "#!" + _details.path;
            _html.append("last write time : " + _details.modified + "&nbsp;&nbsp;&nbsp;files : " + (_details.hasPermission ? _details.fileCount : "Permission denied"));
            _html.find("a").attr("title", _details.name);
            _html.find("a").attr("href", _href);
            _html.find("a span").html("&lt;dir&gt; " + _details.name.substr(0, 40));
            return _html;
        };
        function init() {
            _html = $('<li><a href="#" class="directory"><span></span></a></li>');
        };

        return {
            populateListItem: function (model) {
                return populate(model);
            },
        };
    },
    //--------------------------------------------------------------------------------------------
    // Returns : Object with one public method : 
    //             populateListItem()
    //--------------------------------------------------------------------------------------------
    FileView: function () {
        var _html;
        //--------------------------------------------------------------------------------------------
        // model   : FileModel
        // returns : Html populated with model data.
        //
        // Builds a populated html object for a File item (model) .
        //--------------------------------------------------------------------------------------------
        function populate(model) {
            init();
            var _details = model.getDetails();
            _html.find("a").attr("href", "FileItem/GetFile?path={DIRPATH}&fileName={FILENAME}".replace("{FILENAME}", model.getName()).replace("{DIRPATH}", _details.path));
            _html.find("a").attr("title", model.getName());
            _html.append("created : " + _details.created + "&nbsp;&nbsp;&nbsp;modified : " + _details.modified + "&nbsp;&nbsp;&nbsp;file size : " + _details.length);
            _html.find("a span").html(model.getName().substr(0, 40));
            return _html;
        };
        function init() {
            _html = $('<li><a href="#" download><span></span></a></li>');
        };

        return {
            populateListItem: function (model) {
                return populate(model);
            },
        };
    },
    //--------------------------------------------------------------------------------------------
    // Models
    //--------------------------------------------------------------------------------------------

    //--------------------------------------------------------------------------------------------
    // dirDetails  : Object used to build the Directory model.
    // returns     : Object containing two public methods
    //                getDetails()
    //                getName()
    //--------------------------------------------------------------------------------------------
    DirectoryModel: function (dirDetails) {
        var _fileCount = dirDetails.FileCount;
        var _hasPermission = dirDetails.HasPermission;
        var _modified = util.formatDate(dirDetails.Modified);
        var _name = dirDetails.Name;
        var _path = dirDetails.Path;
        var _parent = dirDetails.Parent;
        var getDirDetails = function () {
            return {
                fileCount: _fileCount,
                hasPermission: _hasPermission,
                modified: _modified,
                name: _name,
                parent: _parent,
                path: _path
            };
        };
        return {
            getDetails: function () {
                return getDirDetails();
            },
            getName: function () {
                return _name;
            }
        };
    },
    //--------------------------------------------------------------------------------------------
    // fileDetails : Object used to build the File model.
    // returns     : Object containing two public methods
    //                getDetails()
    //                getName()
    //--------------------------------------------------------------------------------------------
    FileModel: function (fileDetails) {
        var _created = util.formatDate(fileDetails.Created);
        var _name = fileDetails.Name;
        var _length = fileDetails.Size;
        var _modified = util.formatDate(fileDetails.Modified);
        var _path = fileDetails.Path;
        var getFileDetails = function () {
            return {
                created: _created,
                length: _length,
                modified: _modified,
                name: _name,
                path: _path
            }
        };
        return {
            getDetails: function () {
                return getFileDetails();
            },
            getName: function () {
                return _name;
            }
        };
    }
};

//----------------------------------------------------------------------------------------
//  Utilities
//----------------------------------------------------------------------------------------

var util = {
    //----------------------------------------------------------------------------------------
    // str      : date in format /Date(1494009438817)/
    // dateOnly : default is falsey, pass true or date only
    // return   : Date string formatted: Nov 25 2017, 11:23
    //----------------------------------------------------------------------------------------
    formatDate: function (str, dateOnly) {
        var _dtStr = str;
        var _dtNum = parseInt(_dtStr.replace(/[^0-9]/g, ""));
        var _date = new Date(_dtNum);
        var _formattedDate = _date.toString().substring(3, 15);
        if (!dateOnly)
            _formattedDate += ", " + util.lpad(_date.getHours(), 2) + ":" + util.lpad(_date.getMinutes(), 2);
        return _formattedDate;
    },
    //----------------------------------------------------------------------------------------
    // hash    : hash from url to be cleaned up.
    // returns : array[2]: hashPArts[0] = url, hashParts[1] = filter
    //
    // Replaces | with :, ^ with \ in the hash string so it can be used as a valid path.
    //----------------------------------------------------------------------------------------
    getCleanHash: function (hash) {
        var _regexc = new RegExp("\\|", "g");
        var _regexbs = new RegExp("\\^", "g");
        if (hash.substr(0, 5) === "path=") {
            hash = hash.substr(5);
        }
        var hashParts = hash.split(",filter=");
        hashParts[0] = hashParts[0].replace(_regexc, ":").replace(_regexbs, "\\");
        return hashParts;
    },
    //----------------------------------------------------------------------------------------
    // arg     : the url part
    // filter  : search criteria
    // returns : hash string.
    //
    // Replaces : with |, | with ^ in the arg string then add the filter if it exists
    // so it can be used for hash string.
    //----------------------------------------------------------------------------------------
    getCleanArg: function (arg, filter) {
        var _regexc = new RegExp(":", "g");
        var _regexbs = new RegExp("\\\\", "g");
        var _arg = arg.replace(_regexc, "|").replace(_regexbs, "^");
        return "path=" + _arg + ((typeof filter === "string" && filter.length) ? ",filter=" + filter : "");
    },
    //----------------------------------------------------------------------------------------
    // dir     : the directory to test
    // returns : bool - N.B. will return true on undefined
    //----------------------------------------------------------------------------------------
    isRootDirectory: function (dir) {
        if ((typeof dir === "undefined")
            || (dir.substr(0, 2) === "\\\\")
            || (dir.length === 3 && dir.substr(1, 2) === ":\\")
            || (dir.length === 2 && dir.substr(1, 1) === ":")) {
            return true;
        }
        else {
            return false;
        }
    },
    //----------------------------------------------------------------------------------------
    // str     : string to pad
    // width   : desired string width
    // chr     : character to pad with
    // returns : padded string
    //----------------------------------------------------------------------------------------
    lpad: function (str, width, chr) {
        chr = chr || "0";
        str = str + "";
        return str.length >= width ? str : new Array(width - str.length + 1).join(chr) + str;
    },
    //----------------------------------------------------------------------------------------
    // criteria : string to scrub
    // returns  : scrubbed string
    //----------------------------------------------------------------------------------------
    removeWildCards: function (criteria) {
        var _regexa = new RegExp("\\*", "g");
        var _regexp = new RegExp("\\%", "g");
        return criteria.replace(_regexa, "").replace(_regexp, "");
    }
};


