﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using FileServer.Models;
using FileServer.Controllers;

namespace TestProject.Repositories
{
    public class FileItemRepository
    {
        /// <summary>
        /// Calls Server to search for files and directories/subdirectories matching the criteria.
        /// </summary>
        /// <param name="path">Starting point of the search.</param>
        /// <param name="criteria">The search criteria.</param>
        /// <param name="pattern">The pattern.</param>
        /// <returns>JsonResult - object containing an array of Directories and an array of Files.</returns>
        public JsonResult SearchFiles(string path, string criteria, string pattern)
        {
            var server = new FileServer.Controllers.FileServerController();
            return server.SearchFiles(path, criteria, pattern);
        }

        /// <summary>
        /// Calls server to get the current directory's top level directories and files..
        /// </summary>
        /// <param name="path">The directory path to query.</param>
        /// <returns>JsonResult - object containing an array of Directories and an array of Files.</returns>
        public JsonResult FileList(string path)
        {
            var server = new FileServer.Controllers.FileServerController();
            return server.FileList(path);
        }

        /// <summary>
        /// Call server to download the specified file.
        /// </summary>
        /// <param name="path">The file path.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>FileResult - download file.</returns>
        public FileResult GetFile(string path, string fileName)
        {
            var server = new FileServer.Controllers.FileServerController();
            return server.GetFile(path, fileName);
        }

        /// <summary>
        /// Calls server to upload the file to the specified directory.
        /// Method is asynchronous.  Returns a Json Object containing status 
        /// when complete or on error.
        /// </summary>
        /// <param name="request">The calling request.</param>
        /// <param name="dirpath">The directory to store the file in.</param>
        /// <returns>Asynchronous jsonResult</returns>
        public async Task<JsonResult> UploadFile(HttpRequestBase request, string dirpath)
        {
            var server = new FileServer.Controllers.FileServerController();
            return await server.UploadFile(request, dirpath);
        }
    }
}