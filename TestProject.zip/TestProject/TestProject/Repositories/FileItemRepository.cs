﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using TestProject.Models;
using TestProject.Utilities;

namespace TestProject.Repositories
{
    public class FileItemRepository
    {
        private string dirPath = @"C:\";

        //---------------------------------------------------
        //----------------  Private methods -----------------
        //---------------------------------------------------

        /// <summary>
        /// Primary purpose of this method is to see if the Directory can be read.  It first 
        /// tries CanRead() since that method can return false without generating an exception.  
        ///     If CanRead() returns true
        ///         GetFiles() is called.  
        ///         If GetFiles() fails 
        ///             an exception is thrown and the function will return false.
        ///     If GetFiles succeeds 
        ///         the out parameter fileCount is set to the number of files in the 
        ///         directory and the function will return true.
        /// </summary>
        /// <param name="dir">DirectoryInfo object</param>
        /// <param name="searchPattern">The search pattern.</param>
        /// <param name="fileCount">The file count.</param>
        /// <returns><c>true</c> if CanRead() is true and GetFiles does not throw a permission error, <c>false</c> otherwise.</returns>
        /// <exception cref="System.Exception">Error in getDirectoryFileCount</exception>
        private bool getDirectoryFileCount(DirectoryInfo dir, string searchPattern, out int fileCount)
        {
            fileCount = 0;
            try
            {
                if (Security.CanRead(dir.FullName))
                {
                    fileCount = dir.GetFiles(searchPattern, SearchOption.TopDirectoryOnly).Length;
                }
                else
                {
                    return false;
                }
            }
            catch (System.UnauthorizedAccessException)
            {
                return false;
            }
            catch (System.IO.PathTooLongException)
            {
                return false;
            }
            catch (System.ArgumentException)
            {
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in getDirectoryFileCount : " + ex.Message, ex);
            }
            return true;
        }

        /// <summary>
        /// Returns DirectoryItems with fileCounts for the directories  
        /// immediately below the DirectoryInfo object passed. The function 
        /// also sets the HasPermission flag for each directory.
        /// </summary>
        /// <param name="dir">DirectoryInfo.</param>
        /// <param name="searchPattern">The search pattern.</param>
        /// <param name="option">SearchOption.</param>
        /// <returns>List of DirectoryItems</returns>
        private List<DirectoryItem> getDirectoryItems(DirectoryInfo dir, string searchPattern, SearchOption option)
        {
            var dirItems = new List<DirectoryItem>();

            var directories = dir.EnumerateDirectories(searchPattern, option);
            if (directories.Count() > 0)
            {
                foreach (var d in directories)
                {
                    int fileCount = 0;
                    bool allowDirectory = getDirectoryFileCount(d, searchPattern, out fileCount);
                    dirItems.Add(new DirectoryItem(d) { FileCount = fileCount, HasPermission = allowDirectory });
                }
            }
            return dirItems;
        }

        /// <summary>
        /// Recursive function to get subdirectories.  Used to get a list 
        /// of subdirectories the logged in user can read and to flag those
        /// that cannot be read.
        /// </summary>
        /// <param name="path">Starting point of the search.</param>
        /// <param name="pattern">The search pattern.</param>
        /// <returns>List of DirectoryItems.</returns>
        /// <exception cref="System.Exception">Error in getSubDirectories</exception>
        private List<DirectoryItem> getSubDirectories(string path, string pattern)
        {
            List<DirectoryItem> directories = new List<DirectoryItem>();
            List<DirectoryItem> subDirectories = new List<DirectoryItem>();
            var dir = new DirectoryInfo(path);
            try
            {
                directories.AddRange(getDirectoryItems(dir, pattern, SearchOption.TopDirectoryOnly));
                foreach (var d in directories)
                {
                    if (d.HasPermission)
                    {
                        subDirectories.AddRange(getSubDirectories(d.Path, pattern));
                    }
                }
                directories.AddRange(subDirectories);
                return directories;
            }
            catch (System.UnauthorizedAccessException)
            {
                return directories;
            }
            catch (System.IO.PathTooLongException)
            {
                return directories;
            }
            catch (System.ArgumentException)
            {
                return directories;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in getSubDirectories : " + ex.Message, ex);
            }
        }

        /// <summary>
        /// This is the preferred method for searching for files in a directory.  However if 
        /// it encounters any permission issues, it will generate an exception
        /// </summary>
        /// <param name="dir">DirectoryInfo</param>
        /// <param name="criteria">The search criteria.</param>
        /// <param name="options">SearchOption</param>
        /// <returns>FileInfo[].</returns>
        /// <exception cref="System.Exception">Error in searchFiles</exception>
        private FileInfo[] searchFiles(DirectoryInfo dir, string criteria, SearchOption options)
        {
            criteria = "*" + criteria + "*";
            try
            {
                FileInfo[] files = dir.GetFiles(criteria, SearchOption.AllDirectories);
                return files;
            }
            catch (System.UnauthorizedAccessException)
            {
                return null;
            }
            catch (System.IO.PathTooLongException)
            {
                return null;
            }
            catch (System.ArgumentException)
            {
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in searchFiles : " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Searches for files in a specific directory.  This function is used if the system 
        /// function Directory.GetFiles() cannot be used due to lack of read permission.  
        /// This function is considerably slower than searchFiles().
        /// </summary>
        /// <param name="dirItems">List of DirectoryItem objects.</param>
        /// <param name="criteria">The search criteria.</param>
        /// <returns>FileInfo[].</returns>
        private FileInfo[] searchFilesByDirectory(List<DirectoryItem> dirItems, string criteria)
        {
            criteria = "*" + criteria + "*";
            List<FileInfo> files = new List<FileInfo>();
            foreach (var item in dirItems)
            {
                if (item.HasPermission)
                {
                    try
                    {
                        var dir = new DirectoryInfo(item.Path);
                        files.AddRange(dir.GetFiles(criteria, SearchOption.TopDirectoryOnly));
                    }
                    catch (System.UnauthorizedAccessException)
                    {
                        continue;
                    }
                    catch (System.IO.PathTooLongException)
                    {
                        continue;
                    }
                    catch (System.ArgumentException)
                    {
                        continue;
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Error in searchFilesByDirectory : " + ex.Message, ex);
                    }
                }
            }
            return files.ToArray();
        }


        //---------------------------------------------------
        //----------------  Public methods ------------------
        //---------------------------------------------------

        /// <summary>
        /// Gets all objects in the specified directory only.  Does not get sub directories.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>System.Object - containing an array of DirectorItems and an array of FileItems.</returns>
        public object GetDirectoryObjects(string path)
        {
            string searchPattern = "*.*";
            if (string.IsNullOrEmpty(path))
            {
                path = dirPath;
            }

            var dir = new DirectoryInfo(path);
            var dirItems = getDirectoryItems(dir, searchPattern, SearchOption.TopDirectoryOnly);

            var files = dir.EnumerateFiles(searchPattern, SearchOption.TopDirectoryOnly);
            var fileItems = new List<FileItem>();
            if (files.Count() > 0)
            {
                foreach (var file in files)
                {
                    fileItems.Add(new FileItem(file));
                }
            }
            var Items = new { Directories = dirItems, Files = fileItems };
            return Items;
        }

        /// <summary>
        /// Read the file specified and return a byte array.
        /// </summary>
        /// <param name="path">File path.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>System.Byte[].</returns>
        /// <exception cref="System.Exception">Error in getFileBytes</exception>
        public byte[] GetFileBytes(string path, string fileName)
        {
            try
            {
                return System.IO.File.ReadAllBytes(path + @"\" + fileName);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in getFileBytes : " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Searches the directory and it's subdirectories for files and directories matching the search criteria.
        /// </summary>
        /// <param name="path">The starting point of the search.</param>
        /// <param name="criteria">The search criteria.</param>
        /// <param name="pattern">The pattern.</param>
        /// <returns>System.Object - containing an array of Directories and an array of Files</returns>
        public object SearchDirectory(string path, string criteria, string pattern)
        {
            var dir = new DirectoryInfo(path);
            if (string.IsNullOrEmpty(pattern))
            {
                pattern = "*.*";
            }
            criteria = criteria.Trim(new char[] { '*', '%' });
            var directories = getSubDirectories(path, pattern);
            var dirItems = new List<DirectoryItem>();
            if (directories.Count() > 0)
            {
                var matchDirs = (from d in directories where d.Name.ToLower().Contains(criteria.ToLower()) select d).ToArray();
                foreach (var d in matchDirs)
                {
                    dirItems.Add(d);
                }
            }
            // Try searchFiles first, it is much faster.  It uses a system method but 
            // will return false if there are any permission issues.  
            FileInfo[] files = searchFiles(dir, criteria, SearchOption.AllDirectories);
            if (files == null)
            {
                // If searchFiles returns false, searchFilesByDirectory iterates through
                // the list of directories produced by getSubDirectories()and if permitted 
                // searches the files and subdirectories.
                files = searchFilesByDirectory(directories, criteria);
            }
            var fileItems = new List<FileItem>();
            foreach (var file in files)
            {
                try
                {
                    fileItems.Add(new FileItem(file));
                }
                catch(System.IO.PathTooLongException)
                {
                    continue; // can't do anything with this file so don't display it.
                }
                catch (Exception ex)
                {
                    throw new Exception("Error creating new FileItem in SearchDirectory(). ", ex);
                }
            }
            var Items = new { Directories = dirItems, Files = fileItems };
            return Items;
        }

        /// <summary>
        /// Uploads a file stream to the specified directory.
        /// </summary>
        /// <param name="dirpath">The path.</param>
        /// <param name="stream">The stream.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>Asynchronous - boolean.</returns>
        public async Task<bool> UploadFile(string dirpath, Stream stream, string fileName)
        {
            try
            {
                // get a stream
                var path = Path.Combine(dirpath, fileName);
                using (var fileStream = System.IO.File.Create(path))
                {
                    await stream.CopyToAsync(fileStream);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UploadFile : " + ex.Message, ex);
            }
            return true;
        }
    }
}