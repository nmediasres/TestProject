TestProject
James Fallon
November 26, 2017

About the project:

	TestProject is a basic file system application.  It supports browsing by directory, recursive searching, file download and upload.  Unzip the TesProject.zip file and open the project in Visual Studio 2013.

	Directories are indicated by "<dir>" preceding the directory name.  Clicking on a directory name will navigate to that directory and display it's contents.  You may also navigate to a directory by entering the full path in the Directory textbox and pressing enter or clicking the "Show Files" button.
	
	Listed items not preceded by "<dir>" are files.  Clicking on the file name will download the file if the user has sufficient permissions.
	
	To upload a file, first navigate to the directory you want the file uploaded to, then click the "Choose File" button at the bottom left corner of the page.  Select the file to upload then click the "Upload" button.  The directory display will refresh once the upload has completed.
	
	All directory, parent directory and file links presented on the page are deep links.  Pasting a file link into another browser window/tab will download the file if permitted, directory links will open a new instance of TestProject and display the selected directory. The application itself uses the Google hash/bang pattern to recall the application state (both directory and search criteria) of each page when the back/forward buttons are used.  The URL may be copied to another browser/tab and the application will open in the state indicated by the URL.

	The default directory is c:\.  To change the default, edit the "testProject.defaultDirectory" on line 3 of the file: ~Scripts\testProject.js. 


Limitations when hosting in IIS:

	Upload files is limited to 4GB by IIS (4GB is the limit for IIS/Request Filtering/Edit Feature Settings/maximum allowed content length).  Anything larger than 4GB requires a resumable upload process.

	Directory visibility is quite limited by permissions.

 